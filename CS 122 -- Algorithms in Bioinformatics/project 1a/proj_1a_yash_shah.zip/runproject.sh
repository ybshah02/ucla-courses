#!/bin/bash

python3 read_mapping.py